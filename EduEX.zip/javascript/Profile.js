document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll('.subcourses').forEach(div => div.style.display = 'none'); 
    document.getElementById('Web-Developer').style.display = 'grid';
    document.querySelector(".navbar a").classList.add("active");
});

function showSubcourses(course) {
    document.querySelectorAll('.subcourses').forEach(div => div.style.display = 'none');
    document.getElementById(course).style.display = 'grid';
}